package ATM;

import java.util.Scanner;

public class Atm {
    static float sumTot = 10_000;
    static String checkPin = "2826";
    static String pin;
    static int s = 0;


    public static void greet() {
        System.out.println("Introduce PIN");
        pin = new Scanner(System.in).nextLine();
        if (pin.equals(checkPin)) {
            System.out.println("Bine ati venit!");
        } else {
            s++;
            chechPin();
        }
    }

    public static void chechPin() {
        int dec = 3;
        System.out.println("PIN incorect");
        for (int i = 2; i > 0; --i) {
            dec -= s;
            System.out.println("Au mai ramas " + dec + " incecare");
            break;
        }
        if (dec == 0) {
            System.out.println("Cont blocat");
            System.exit(0);
        }
        greet();
    }

    public static void start() {
        System.out.println("==========ATM MENU==========");
        System.out.println("Alege op.1 pentru a retrage");
        System.out.println("Alege op.2 pentru incarcare cont");
        System.out.println("Alege op.3 pentru a vizualiza balanta contului");
        System.out.println("Alege op.4 pentru iesire");
    }

    public static void operatiune() {
        int op = new Scanner(System.in).nextInt();
        switch (op) {
            case 1:
                retragere();
                break;
            case 2:
                depozit();
                break;
            case 3:
                afisare();
                break;
            case 4:
                exit();
                break;
            default:
                System.out.println("Introduce doar datele afisate pe ecran");
        }
    }

    public static void retragere() {
        float ret;
        System.out.println("Introduce suma de retragere");
        ret = new Scanner(System.in).nextFloat();
        if (ret <= sumTot) {
            sumTot -= ret;
            System.out.println("Retragere cu succes\n");
        } else
            System.out.println("Resurse insuficiente.\nVerificati balanta contului!");

    }

    public static void depozit() {
        System.out.println("Introduce suma pentru depozitare:");
        float dep = new Scanner(System.in).nextFloat();
        sumTot += dep;
        System.out.println("Suma depozitata cu succes\n");
    }

    public static void afisare() {
        System.out.println("Suma disponibila:" + sumTot + " mdl\n");
    }

    public static void exit() {
        System.out.println("O zi buna sa aveti!");
        System.exit(0);
    }
}
