package ATM;

import static ATM.Atm.*;

public class Main {
    public static void main(String[] args) {
        greet();
        while (true){
        start();
        operatiune();
    }}
}
